package com.c3.actividad4;


import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductoListController {

    private final List<Producto> productos = new ArrayList<>();

    @PostMapping("/add")
    public Producto agregarProducto(@RequestBody Producto producto) {
        productos.add(producto);
        return producto;
    }

    @GetMapping("/productos")
    public List<Producto> obtenerProductos() {
        return productos;
    }
}
