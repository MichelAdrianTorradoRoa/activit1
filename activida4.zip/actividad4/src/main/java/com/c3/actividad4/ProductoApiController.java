package com.c3.actividad4;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ProductoApiController {

    @PostMapping("/producto")
    public Producto registrarProducto(@RequestBody Producto producto) {
        return producto;
    }
}
