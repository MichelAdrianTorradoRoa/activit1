package com.c3.actividad4;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class actividad4 {

    @PostMapping("/registrar")
    public String registrarProducto(@RequestParam String nombre,
                                    @RequestParam double precio,
                                    @RequestParam String descripcion,
                                    Model model) {
        Producto producto = new Producto(nombre, precio, descripcion);
        model.addAttribute("producto", producto);
        return "respuesta";
    }
}
