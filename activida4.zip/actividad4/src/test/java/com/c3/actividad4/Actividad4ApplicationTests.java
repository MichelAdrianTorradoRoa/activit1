package com.c3.actividad4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Actividad4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
