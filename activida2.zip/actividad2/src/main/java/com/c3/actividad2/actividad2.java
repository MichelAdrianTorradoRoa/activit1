package com.c3.actividad2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class actividad2 {
    @RequestMapping("/api/producto")
    @ResponseBody
    public Producto producto(){
        Producto producto = new Producto("Celular", 500.000,"Xiaomi POCO M4 Pro 5G");
        return producto;
    }
}
