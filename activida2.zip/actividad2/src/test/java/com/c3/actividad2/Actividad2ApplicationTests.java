package com.c3.actividad2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Actividad2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
