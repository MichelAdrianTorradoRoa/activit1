package com.c3.actividad3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Actividad3Application {

	public static void main(String[] args) {
		SpringApplication.run(Actividad3Application.class, args);
	}

}
