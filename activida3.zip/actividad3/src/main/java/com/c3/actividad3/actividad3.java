package com.c3.actividad3;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.ArrayList;

@RestController
public class actividad3 {
    @RequestMapping("/api/clientes")
        public List<Cliente> getCliente(){
            List<Cliente> clientes = new ArrayList<>();
            clientes.add(new Cliente("Juan",25));
            clientes.add(new Cliente("David",35));
            clientes.add(new Cliente("Alexis",45));
            clientes.add(new Cliente("Joan",55));
            clientes.add(new Cliente("Victor",65));
            return clientes;
        }
}
