package com.c3.ejercicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
